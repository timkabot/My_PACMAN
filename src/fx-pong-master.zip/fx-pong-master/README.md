# Pong

See [http://svanimpe.be/blog/pong.html](http://svanimpe.be/blog/pong.html) for information.  
See [http://svanimpe.be/blog/pong-ios.html](http://svanimpe.be/blog/pong-ios.html) for information on the **ios** branch.

This repository contains a Maven project. It was last tested using NetBeans 8.0.2 and JDK 8u25.
